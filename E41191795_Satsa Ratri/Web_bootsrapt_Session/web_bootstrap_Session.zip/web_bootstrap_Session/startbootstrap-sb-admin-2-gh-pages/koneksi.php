<?php  

	$db = mysqli_connect("localhost","root","","db_praktikumlogindb");

	if (mysqli_connect_error()) {

		echo "Koneksi Gagal : ".mysql_connect_error() ;
	}
?>